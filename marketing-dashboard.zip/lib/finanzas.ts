// lib/finanzas.ts
import { apiFetchAuth } from "./api"

// =======================
// Types
// =======================

export type FinanzasDashboardRequest = {
    fechaDesde: string | null
    fechaHasta: string | null
    cuentaId: number | null
    moneda: string | null
    meses: number | null
    topCategorias?: number | null
    ultimosMovimientos: number | null
}

export type DashboardKpis = {
    desde: string
    hasta: string
    moneda: string
    ingresos: number
    egresos: number
    neto: number
    reversas: number
}

export type ReporteMes = {
    mes: string // "YYYY-MM"
    moneda: string
    ingresos: number
    egresos: number
    neto: number
}

export type MovimientoFinancieroDto = {
    id: number
    codigo: string
    cuentaId: number | null
    cuentaNombre: string | null
    fecha: string // "YYYY-MM-DD"
    direccion: number
    estado: number
    categoriaId: number | null
    categoriaNombre: string | null
    concepto: string
    descripcion: string | null
    clienteId: number | null
    proyectoId: number | null
    facturaId: number | null
    monto: number
    moneda: string
    esReversa: boolean
    movimientoOrigenId: number | null
    referenciaExterna: string | null
    creadoEn: string
    actualizadoEn: string

    // auditoría
    creadoPorId: number | null
    creadoPorNombre: string | null
    creadoPorEmail: string | null
    actualizadoPorId: number | null
    actualizadoPorNombre: string | null
    actualizadoPorEmail: string | null
}

export type FinanzasDashboardResponse = {
    kpisMesActual: DashboardKpis
    porMes: ReporteMes[]
    ultimosMovimientos: MovimientoFinancieroDto[]
}

type ApiResponse<T> = {
    estado: boolean
    error_mensaje: string | null
    datos: T | null
}

// =======================
// Dashboard
// =======================

export async function fetchFinanzasDashboard(body: FinanzasDashboardRequest): Promise<FinanzasDashboardResponse> {
    const r = await apiFetchAuth<FinanzasDashboardResponse>("/api/v1/finanzas/dashboard", {
        method: "POST",
        body,
    })

    if (!r.estado) throw new Error(r.error_mensaje ?? "Error en dashboard")
    if (!r.datos) throw new Error("Respuesta vacía de dashboard")
    return r.datos
}

// =======================
// Referencias (cuentas / categorías) para el modal "Nuevo movimiento"
// =======================

export type FinanzasCuenta = {
    id: number
    nombre: string
    moneda: string
    tipo?: number | null
    activo?: boolean | null
}

export type FinanzasCategoria = {
    id: number
    nombre: string
    direccionDefecto?: number | null
    parentId?: number | null
    activa?: boolean | null
}

export type FinanzasRefs = {
    cuentas: FinanzasCuenta[]
    categorias: FinanzasCategoria[]
}

/**
 * Trae refs para formularios:
 * - cuentas financieras
 * - categorías financieras
 *
 * ⚠️ Ajustá los paths si tus endpoints reales difieren.
 */
export async function getFinanzasRefs(): Promise<FinanzasRefs> {
    // Estos endpoints suelen existir en tu backend:
    // - /api/v1/finanzas/cuentas/buscar
    // - /api/v1/finanzas/categorias/buscar
    //
    // Si tus paths son otros, decime cuáles y lo adapto.
    const cuentasR = await apiFetchAuth<{ contenido: FinanzasCuenta[] }>("/api/v1/finanzas/cuentas/buscar", {
        method: "POST",
        body: { q: null, moneda: null, activo: true, page: 0, size: 200 },
    })

    if (!cuentasR.estado) throw new Error(cuentasR.error_mensaje ?? "Error cargando cuentas")
    const cuentas = cuentasR.datos?.contenido ?? []

    const catsR = await apiFetchAuth<{ contenido: FinanzasCategoria[] }>("/api/v1/finanzas/categorias/buscar", {
        method: "POST",
        body: { q: null, activa: true, page: 0, size: 500 },
    })

    if (!catsR.estado) throw new Error(catsR.error_mensaje ?? "Error cargando categorías")
    const categorias = catsR.datos?.contenido ?? []

    return { cuentas, categorias }
}

// =======================
// Crear movimiento
// =======================

export type MovimientoCreateRequest = {
    cuentaId: number
    fecha: string // "YYYY-MM-DD"
    direccion: 1 | 2
    estado?: 1 | 2 | null
    categoriaId: number
    concepto: string
    descripcion?: string | null
    clienteId?: number | null
    proyectoId?: number | null
    facturaId?: number | null
    monto: number
    moneda: string // "ARS"
}

export async function crearMovimientoFinanciero(body: MovimientoCreateRequest): Promise<MovimientoFinancieroDto> {
    const r = await apiFetchAuth<MovimientoFinancieroDto>("/api/v1/finanzas/movimientos", {
        method: "POST",
        body,
    })

    if (!r.estado) throw new Error(r.error_mensaje ?? "Error creando movimiento")
    if (!r.datos) throw new Error("Respuesta vacía al crear movimiento")
    return r.datos
}

// =======================
// Cache helpers (localStorage)
// =======================

const LS_LAST_SELECTION = "finanzas:lastSelection:v1"

export type FinanzasLastSelection = {
    cuentaId: number | null
    categoriaId: number | null
    moneda: string | null
}

export function getFinanzasLastSelection(): FinanzasLastSelection {
    if (typeof window === "undefined") return { cuentaId: null, categoriaId: null, moneda: null }
    try {
        const raw = window.localStorage.getItem(LS_LAST_SELECTION)
        if (!raw) return { cuentaId: null, categoriaId: null, moneda: null }
        const parsed = JSON.parse(raw) as FinanzasLastSelection
        return {
            cuentaId: typeof parsed?.cuentaId === "number" ? parsed.cuentaId : null,
            categoriaId: typeof parsed?.categoriaId === "number" ? parsed.categoriaId : null,
            moneda: typeof parsed?.moneda === "string" ? parsed.moneda : null,
        }
    } catch {
        return { cuentaId: null, categoriaId: null, moneda: null }
    }
}

export function setFinanzasLastSelection(next: FinanzasLastSelection) {
    if (typeof window === "undefined") return
    try {
        window.localStorage.setItem(LS_LAST_SELECTION, JSON.stringify(next))
    } catch {
        // noop
    }
}